/**
 * Copyright (C) 2018 Juridoc
 * Form module.
 */
export { View } from './view';
