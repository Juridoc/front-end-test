const form = require('node-fetch')

const urlPost = 'https://test.juridoc.io/register'

fetch(urlPost,{
    method:'POST',
    body: JSON.stringify(form)

    "firstName": "Someone",
    "lastName": "Someone",
    "phone": "11 1234-4321",
    "email": "someone@juridoc.io",
    "username": "someone",
    "password": "000000"
})
    .then((res)=>res.json())
    .then((json)=>console.log(json)
    .catch((e)=>console.log(e))
)
