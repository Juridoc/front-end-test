

const form = require('node-fetch')

const urlPost = 'https://test.juridoc.io/register'

fetch(urlPost,{
    method:'POST',
    body: JSON.stringify(form)

    [{    
    "first-name": "Someone",
    "last-name": "Someone",
    "phone": "11 1234-4321",
    "email": "someone@juridoc.io",
    "user-name": "someone",
    "password": "000000"
    }]

    .then((res)=>res.json())
    .then((json)=>console.log(json)
    .catch((e)=>console.log(e));
